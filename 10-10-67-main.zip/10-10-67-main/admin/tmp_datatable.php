<?php
include 'header.php';
include 'navbar.php';
include 'sidebar.php';
include 'tmp_datatable_content.php';
include 'footer.php';
?>